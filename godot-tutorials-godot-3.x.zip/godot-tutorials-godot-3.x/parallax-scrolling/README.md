[![thumbnail](thumbnail.jpg)](https://www.youtube.com/watch?v=f8z4x6R7OSM)

# Godot Tutorial: Parallax Scrolling

In this tutorial I am going to guide you through the process of adding Parallax Scrolling to your Godot game.