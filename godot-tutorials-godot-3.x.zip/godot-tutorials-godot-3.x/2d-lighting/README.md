[![thumbnail](thumbnail.jpg)]()

# Godot Tutorial: Xbox Controller Support

In this tutorial I am going to guide you through the process of adding 2D lighting to your Godot Engine game!